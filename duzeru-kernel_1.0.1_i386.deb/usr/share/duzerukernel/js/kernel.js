function kernelCtrl($scope) {

}
